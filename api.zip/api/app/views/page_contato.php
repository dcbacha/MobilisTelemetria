<?php //require ("navbars.php");
?>
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/commonfunctions.js"></script>
  <script src="js/main_contato.js"></script>
  <style type="text/css">
  	
    .faq-questions{
      border-right: 0px;
      border-left: 0px;
    }

    .row {
      margin-bottom: 0px;
    }
  
  </style>


<div class="container faq">

<div class="row center">
    <h5 class="header col s12 light">Contato</h5>
</div> <!-- end row -->
  <div class="divider"></div>

<div class='row'>
<p>Mobilis Veículos Elétricos</p>
<p>Telefone </p>
<p>Floarianópolis, SAnta Catarina</p>
<p>ETC..</p>

</div>





</div><!-- end container -->


     
   





</body>
</html>