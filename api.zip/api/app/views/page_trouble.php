<?php //require ("navbars.php");
?>
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/materialize.js"></script>
  <script src="js/commonfunctions.js"></script>
  <script src="js/main_trouble.js"></script>
  <style type="text/css">
  	
    .row {
      margin-bottom: 0px;
    }
  
  </style>


<div class="container">

<div class="row center">
    <h5 class="header col s12 light">Troubleshooting</h5>
        <a class="btn-floating right smallround  tooltipped" data-position='bottom' data-delay='500' data-tooltip='Passos para tentar entender e resolver o problema' id="info">
          <i class='material-icons valign-wrapper'>info_outline</i>
        </a>
</div> <!-- end row -->
  <div class="divider"></div>

<div class='row'>

</div>





</div><!-- end container -->


     
   





</body>
</html>